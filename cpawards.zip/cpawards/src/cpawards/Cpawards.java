/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cpawards;

import javax.swing.JOptionPane;

/**
 *
 * @author miguel.prodrigues1
 */
public class Cpawards {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    JOptionPane.showMessageDialog(null,"caralhos duros sobrevoando o seu quintal?");
    JOptionPane.showMessageDialog(null,"sim estao");
    }
    
}
